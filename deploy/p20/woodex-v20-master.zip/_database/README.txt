This folder is blocked from the web (.htaccess). woodex-v20.sql = all 16 tables + login admin/admin.
The installer (/wx-install.php) uses it automatically. Or import it in phpMyAdmin.
