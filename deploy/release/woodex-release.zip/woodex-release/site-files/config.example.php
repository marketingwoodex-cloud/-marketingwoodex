<?php
// EXAMPLE ONLY: placeholders, no real password. This file is not used by the site and is safe to delete.
// Woodex stores the real database settings in public_html/_private/db.json, created by Admin setup
// (https://woodex.com.pk/admin/). _private/ is blocked from the web by its own .htaccess.
http_response_code(404); exit; // never outputs anything if opened in a browser
return [
    'host' => 'localhost',
    'name' => 'u000000000_woodex',
    'user' => 'u000000000_woodex',
    'pass' => 'PUT-YOUR-DATABASE-PASSWORD-HERE',
];
