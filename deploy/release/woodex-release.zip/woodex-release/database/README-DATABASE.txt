WOODEX DATABASE
===============
This folder is NEVER uploaded to public_html.

1) New install: create an empty MySQL database in Hostinger, then run Admin setup.
   All tables are created automatically. Nothing needs importing.

2) Moving your existing data (recommended before every big update):
   hPanel -> Databases -> phpMyAdmin -> choose u128159657_woodex -> Export -> Quick -> SQL -> Go.
   Save the file here as:  database/woodex.sql   (or zip it: woodex.sql.zip)
   To restore: phpMyAdmin -> choose the database -> Import -> select woodex.sql -> Go.
   Or use Admin -> Settings -> Backups (Owner only), which also includes pages and images.

woodex.sql (in this package) = base table STRUCTURE only, no data. Replace it with your own phpMyAdmin export (same name) to keep a real backup.
Keep woodex.sql private: it contains client data and password hashes.
