# Woodex Admin v3 — Preline Ocean Edition

## Features
- Complete 6-Hub Navigation (52 screens).
- Preline Ocean Design System & Inter typography.
- Glassmorphic Obsidian Login with Google Workspace SSO.
- Real-time API Client & JSON Driver.

## Quick Install on Hostinger / Apache
1. Upload the contents of this zip to your `public_html/`.
2. Ensure `/admin-v3/` points to `admin-v3/index.html`.
3. Default credentials:
   - Master: `master@woodex.pk` / `Woodex@2026`
